declare module 'qrcode';
